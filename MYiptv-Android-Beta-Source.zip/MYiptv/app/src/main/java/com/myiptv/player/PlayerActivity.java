package com.myiptv.player;

import android.os.Bundle;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class PlayerActivity extends AppCompatActivity {
    private ExoPlayer player;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.BLACK);
        TextView title=new TextView(this); title.setText("  ◀  "+getIntent().getStringExtra("name")); title.setTextSize(19); title.setTextColor(Color.WHITE); title.setPadding(12,18,12,18); title.setFocusable(true); title.setOnClickListener(v->finish()); root.addView(title);
        PlayerView view=new PlayerView(this); view.setUseController(true); root.addView(view,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        player=new ExoPlayer.Builder(this).build(); view.setPlayer(player);
        String url=getIntent().getStringExtra("url");
        if(url!=null && !url.isEmpty()) { player.setMediaItem(MediaItem.fromUri(url)); player.prepare(); player.play(); }
        title.requestFocus();
    }
    @Override protected void onStop(){super.onStop(); if(player!=null){player.release();player=null;}}
}
