# MYiptv — Android Beta 0.1

Native Java Android project. Black/purple UI. Supports touch and basic D-pad focus for Android TV and Fire TV.

## Features implemented
- Import remote HTTP(S) M3U playlists; parse `#EXTINF`, `tvg-logo`, `group-title`, `#EXTGRP`, and optional `content-type` / `type` metadata.
- Browse Live TV / Movies / Series, category filters, instant search, favorite toggles persisted locally.
- Stream playback using AndroidX Media3 ExoPlayer (HLS and supported progressive streams).
- Remembers the most recently imported playlist URL and reloads it at launch.
- Launcher entries for phones and Android TV.

## Build APK in Android Studio
1. Install Android Studio (recent version with Android SDK 35 and JDK 17).
2. Open this **MYiptv** folder as a Gradle project. Allow Gradle sync and dependencies to download.
3. In Android Studio choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.
5. Enable developer options/USB debugging or allow test-app installation on your Android device. Install via `adb install -r app/build/outputs/apk/debug/app-debug.apk` or transfer the APK.
6. Launch MYiptv, enter a valid authorized M3U URL, tap Import Playlist, then choose a stream.

CLI alternative, if Gradle 8.9 and Android SDK 35 are installed: `gradle assembleDebug`.

## Known beta limitations
- Not yet compiled or device-tested in this environment; there is no verified APK included.
- VOD and series detection depends on playlist `group-title` / `type` metadata; there is no automatic Xtream Codes API, series season grouping, or EPG integration yet.
- M3U headers/cookies/DRM and unusual stream formats are not implemented; stream compatibility depends on device codecs and server access.
- Channel logos are parsed but not displayed in this initial UI.
- Remote-control focus is basic; advanced TV 10-foot UX needs device testing and refinement.
- Playback errors are not yet presented with a dedicated error screen.
- Playlist import reads the full playlist into memory; large lists may need paging/storage.
- HTTP cleartext is enabled for compatibility with user-supplied local streams; production builds should narrow network policy.
- Avoid untrusted playlist URLs and only stream content you are authorized to access.
- Samsung Tizen, LG webOS and iOS require separate platform builds; this APK does not install on those systems.

## Project layout
- `app/src/main/java/com/myiptv/player/MainActivity.java` — playlist import and browser
- `app/src/main/java/com/myiptv/player/M3uParser.java` — playlist parser
- `app/src/main/java/com/myiptv/player/PlayerActivity.java` — Media3 player
- `app/src/main/java/com/myiptv/player/Channel.java` — media entry model

## Privacy
The app stores the last playlist URL and favorites in local app preferences. Do not use URLs with embedded secrets on shared devices. No account backend or telemetry is included.
