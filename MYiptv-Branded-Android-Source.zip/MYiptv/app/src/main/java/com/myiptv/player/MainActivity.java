package com.myiptv.player;

import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    private final int BG=Color.rgb(9,7,15), PANEL=Color.rgb(26,20,39), PURPLE=Color.rgb(168,85,247), WHITE=Color.WHITE, MUTED=Color.rgb(177,165,192);
    private final ArrayList<Channel> channels=new ArrayList<>();
    private final Set<String> favorites=new HashSet<>();
    private LinearLayout root, list, filters;
    private EditText search;
    private String tab="Live TV", category="All";
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable background(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private void pad(View v,int h,int y){v.setPadding(dp(h),dp(y),dp(h),dp(y));}
    private void addSpace(LinearLayout parent,int height){View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(1,dp(height)));}
    @Override public void onCreate(Bundle state){super.onCreate(state); favorites.addAll(getPreferences(0).getStringSet("favorites",new HashSet<>())); showBrandSplash(); String saved=getPreferences(0).getString("playlist",""); if(!saved.isEmpty())loadPlaylist(saved);}
    private void showBrandSplash() {
        LinearLayout splash=new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setBackgroundColor(BG);
        ImageView logo=new ImageView(this);
        logo.setImageResource(R.drawable.myiptv_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        splash.addView(logo,new LinearLayout.LayoutParams(dp(260),dp(220)));
        TextView tagline=text("YOUR ENTERTAINMENT. YOUR PLAYLIST.",12,MUTED,true);
        tagline.setGravity(Gravity.CENTER);
        splash.addView(tagline);
        setContentView(splash);
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(this::build,1100);
    }
    private void build(){
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);pad(root,16,20);scroll.addView(root);setContentView(scroll);
        ImageView brand=new ImageView(this);
        brand.setImageResource(R.drawable.myiptv_logo);
        brand.setScaleType(ImageView.ScaleType.FIT_START);
        root.addView(brand,new LinearLayout.LayoutParams(dp(170),dp(95)));
        TextView title=text("MY IPTV",26,WHITE,true);root.addView(title);
        TextView subtitle=text("YOUR ENTERTAINMENT. YOUR PLAYLIST.",11,MUTED,false);root.addView(subtitle);addSpace(root,20);
        TextView label=text("M3U / M3U8 PLAYLIST URL",12,MUTED,true);root.addView(label);addSpace(root,6);
        EditText url=new EditText(this);url.setSingleLine(true);url.setTextColor(WHITE);url.setHintTextColor(MUTED);url.setTextSize(14);url.setHint("https://example.com/playlist.m3u");url.setInputType(17);url.setBackground(background(PANEL,12));pad(url,14,12);url.setText(getPreferences(0).getString("playlist",""));root.addView(url,new LinearLayout.LayoutParams(-1,dp(52)));addSpace(root,10);
        Button load=button("IMPORT PLAYLIST");root.addView(load);load.setOnClickListener(v->{String value=url.getText().toString().trim();if(!value.isEmpty())loadPlaylist(value);});
        addSpace(root,20);
        LinearLayout nav=new LinearLayout(this);nav.setOrientation(LinearLayout.HORIZONTAL);root.addView(nav);
        for(String name:new String[]{"Live TV","Movies","Series","Favorites"}){
            TextView b=text(name,13,WHITE,true);b.setGravity(Gravity.CENTER);b.setFocusable(true);pad(b,8,14);b.setBackground(background(name.equals(tab)?PURPLE:PANEL,10));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(48),1);p.setMargins(dp(2),0,dp(2),0);nav.addView(b,p);b.setOnClickListener(v->{tab=name;category="All";build();});
        }
        addSpace(root,16);
        search=new EditText(this);search.setSingleLine(true);search.setTextColor(WHITE);search.setHintTextColor(MUTED);search.setHint("Search channels and titles...");search.setTextSize(15);search.setBackground(background(PANEL,10));pad(search,14,10);root.addView(search,new LinearLayout.LayoutParams(-1,dp(48)));
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int f){}public void onTextChanged(CharSequence s,int a,int b,int c){renderList();}public void afterTextChanged(android.text.Editable e){}});
        addSpace(root,12);
        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);filters=new LinearLayout(this);filters.setOrientation(LinearLayout.HORIZONTAL);hsv.addView(filters);root.addView(hsv);addSpace(root,12);
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);
        renderFilters();renderList();
    }
    private Button button(String label){Button b=new Button(this);b.setText(label);b.setTextColor(WHITE);b.setTextSize(13);b.setAllCaps(false);b.setBackground(background(PURPLE,12));b.setFocusable(true);return b;}
    private void renderFilters(){if(filters==null)return;filters.removeAllViews();LinkedHashSet<String> groups=new LinkedHashSet<>();groups.add("All");for(Channel c:channels)if(matchesTab(c))groups.add(c.group);for(String g:groups){TextView chip=text(g,12,WHITE,false);pad(chip,12,9);chip.setFocusable(true);chip.setBackground(background(g.equals(category)?PURPLE:PANEL,9));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);lp.setMargins(0,0,dp(7),0);filters.addView(chip,lp);chip.setOnClickListener(v->{category=g;renderFilters();renderList();});}}
    private boolean matchesTab(Channel c){return tab.equals("Favorites")?favorites.contains(c.url):c.type.equals(tab);}
    private void renderList(){if(list==null)return;list.removeAllViews();int count=0;String q=search==null?"":search.getText().toString().toLowerCase(Locale.ROOT);for(Channel c:channels){if(!matchesTab(c)||(!category.equals("All")&&!category.equals(c.group))||!(c.name+" "+c.group).toLowerCase(Locale.ROOT).contains(q))continue;count++;LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.HORIZONTAL);card.setGravity(Gravity.CENTER_VERTICAL);card.setBackground(background(PANEL,12));pad(card,12,12);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,dp(8));list.addView(card,cp);
        TextView play=text("▶",21,PURPLE,true);play.setGravity(Gravity.CENTER);card.addView(play,new LinearLayout.LayoutParams(dp(38),dp(54)));
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);card.addView(info,new LinearLayout.LayoutParams(0,-2,1));TextView name=text(c.name,16,WHITE,true);name.setMaxLines(2);info.addView(name);TextView group=text(c.group,12,MUTED,false);info.addView(group);
        TextView star=text(favorites.contains(c.url)?"★":"☆",27,PURPLE,false);star.setGravity(Gravity.CENTER);star.setFocusable(true);card.addView(star,new LinearLayout.LayoutParams(dp(46),dp(54)));star.setOnClickListener(v->{if(!favorites.add(c.url))favorites.remove(c.url);getPreferences(0).edit().putStringSet("favorites",new HashSet<>(favorites)).apply();renderList();});
        card.setFocusable(true);card.setOnClickListener(v->{Intent i=new Intent(this,PlayerActivity.class);i.putExtra("name",c.name);i.putExtra("url",c.url);startActivity(i);});
    }
    if(count==0){TextView empty=text(channels.isEmpty()?"Add an M3U playlist URL to begin.":"No items in this section. Try another category or search.",15,MUTED,false);pad(empty,10,30);list.addView(empty);}TextView footer=text(count+" items • MYiptv Beta",12,MUTED,false);pad(footer,4,14);list.addView(footer);}
    private void loadPlaylist(String address){
        if(!(address.startsWith("https://")||address.startsWith("http://"))){Toast.makeText(this,"Enter an HTTP(S) playlist URL",Toast.LENGTH_LONG).show();return;}
        Toast.makeText(this,"Loading playlist...",Toast.LENGTH_SHORT).show();
        new Thread(()->{try{
            URL url=new URL(address);URLConnection connection=url.openConnection();connection.setConnectTimeout(12000);connection.setReadTimeout(20000);connection.setRequestProperty("User-Agent","MYiptv/0.1");
            if(connection instanceof HttpURLConnection){int status=((HttpURLConnection)connection).getResponseCode();if(status<200||status>=300)throw new IOException("HTTP "+status);}
            List<Channel> imported;try(InputStream stream=connection.getInputStream();Reader reader=new InputStreamReader(stream,StandardCharsets.UTF_8)){imported=M3uParser.parse(reader);}
            if(imported.isEmpty())throw new IOException("No playable HTTP(S)/RTSP entries found");
            runOnUiThread(()->{channels.clear();channels.addAll(imported);getPreferences(0).edit().putString("playlist",address).apply();category="All";tab="Live TV";build();Toast.makeText(this,"Imported "+imported.size()+" entries",Toast.LENGTH_LONG).show();});
        }catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Import failed: "+e.getMessage(),Toast.LENGTH_LONG).show());}}).start();
    }
}
