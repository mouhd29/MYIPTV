MYIPTV logo assets

Copy the app/src/main/res directories into the corresponding Android app module.
In AndroidManifest.xml, on the <application> tag, use:
 android:icon="@mipmap/ic_launcher"
 android:banner="@drawable/tv_banner"

For a branded splash or header, use @drawable/myiptv_logo in the relevant Android layout or Compose Image painterResource.

Note: This asset package does not automatically change the existing GitHub APK. The Android project must be updated and rebuilt.
